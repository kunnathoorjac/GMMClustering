clear
close all
clc
% calling fumction and collecting required outputs
[a,b,c,d,e,f,g,h]=GMMClustering(8)
%% 
x=xlsread('tSNE_DR.xlsx');
b=zeros(size(x));
sigma=cat(3,g(1,1),g(1,2),g(1,3),g(1,4),g(1,5),g(1,6),g(1,7),g(1,8));
sigma=cell2mat(sigma);
% writing expression for pdf using gmm
for n=1:size(x)
    for k=1:8
        y(n,k)=h(k)*mvnpdf(x(n,:),f(k),sigma(:,:,k));
        b(n)=b(n)+y(n,k);
    end
end
%% 
% defining range to be used in ks density
p=zeros(756,2);
for j=1:2
    for i=1:756
        p(i,j)= min(x(i,j))+(i-1)*((max(x(i,j))-min(x(i,j)))/756);
    end
end
% using ks density to find empirical pdf
 [u,xi]=ksdensity(x,p)  
o=zeros(756,1);
r=zeros(756,1);
% using KL divergence equation
for i=1:756
    o(i)=log(u(i)/b(i));
    r(i)=u(i)*o(i);
end
kl=sum(r)