% Finding BIC
a=[2:1:10];
%BIC = -2 * LL + log(N) * k
n=756;
% Likelihood values upto 8 clusters
l=[-8.3201,-8.1783,-8.0986,-8.0373,-7.9770,-7.9422,-7.9208,-7.8336,-7.8108];
b=zeros(1,9);
%Define no. of GMM parameters
k=zeros(1,9);
for i=1:9
    k(i)=3*a(i)-1;
    b(i)=-2*l(i)+(log(n)*k(i));
end
% plotting results 
figure(1)
plot(a,b)
title('BIC');
xlabel('No.of clusters');
ylabel('BIC');
c=gradient(b);
figure(2)
plot(a,c)
title('gradBIC');
xlabel('No.of clusters');
ylabel('gradBIC');
figure(3)
plot(a,l)
title('Loglikelihood');
xlabel('no.of clusters');
ylabel('loglikelihood');

